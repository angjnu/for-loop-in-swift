 
//  main.swift
//  Loops
//
//  Created by anil kumar giri on 21/02/16.
//  Copyright © 2016 AKG. All rights reserved.

import Foundation
 //simple for loop
var i=0
for i=1; i<10; i++ {
    print("the value of i =\(i)")
}
// for-in
let x = ["hello", "hi", "thanks"]
for i in x
{
    print("the value of i =\(i)")

}
// if you want to ignore use this
 for _ in 1...10 {
    print("hello")
 }
 var animals=["Cow": 8, "human" : 2, "ant": 6 ]
 for (name, nooflegs) in animals{
    print("Animal \(name) has \(nooflegs) legs")
 }
 